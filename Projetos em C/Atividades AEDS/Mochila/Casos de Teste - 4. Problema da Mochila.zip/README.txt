Arquivo zip gerado em: 24/02/2021 22:13:38 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: 4. Problema da Mochila